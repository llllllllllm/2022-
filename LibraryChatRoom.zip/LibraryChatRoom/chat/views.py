from datetime import timedelta

from django.shortcuts import render, redirect, HttpResponse
from django.views import View
from django.contrib import messages
from chat.models import *
from chat import models
from django.db.models import Avg, Max, Min, Count, Sum


class RoomView(View):
    """
    聊天室视图
    """

    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')

        user_id = request.session['user_id']
        user_name = User.objects.filter(id=user_id).first().name
        room_num = request.GET.get("num")

        return render(request, 'room.html', locals())


class IndexView(View):
    """
    主页视图
    """

    def get(self, request):
        return redirect("/login/")


class LoginView(View):
    """
    登陆视图
    """

    def get(self, request):
        if request.session.get('is_login', None):
            return redirect('/home/')
        return render(request, "login.html", locals())

    def post(self, request):
        user_id = request.POST.get('id')
        password = request.POST.get("password")
        user = User.objects.filter(id=user_id).first()
        if user and user.password == password:
            request.session['is_login'] = True
            request.session['user_id'] = user.id
            request.session['user_name'] = user.name
            messages.success(request, '登陆成功！')
            return redirect('/home/')
        else:
            messages.error(request, '用户名或密码错误！')
        return render(request, 'login.html', locals())


class LogoutView(View):
    """
    登出视图
    """

    def get(self, request):
        if request.session.get('is_login', None):
            request.session.flush()
            messages.success(request, '登出成功！')
        return redirect('/login/')


class RegisterView(View):
    """
    注册视图
    """

    def get(self, request):
        return render(request, 'register.html', locals())

    def post(self, request):
        user_name = request.POST.get('name')
        user_id = request.POST.get('id')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        if password1 == password2:
            same_id_users = User.objects.filter(id=user_id)
            if same_id_users:
                messages.error(request, '该学号已被注册！')
            else:
                User.objects.create(id=user_id, name=user_name, password=password1)
                messages.success(request, '注册成功！')
                return redirect('/login/')
        else:
            messages.error(request, '两次输入的密码不一致！')

        return render(request, 'register.html', locals())


class HomeView(View):
    """
    个人中心
    """

    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')
        user_id = request.session['user_id']
        user_name = User.objects.filter(id=user_id).first().name
        author = models.Author.objects.all()
        publisher = models.Publisher.objects.all()
        major = models.Major.objects.all()
        books = Book.objects.filter(borrow__user=user_id)
        return render(request, 'home.html', locals())

    def post(self, request):
        post_author = request.POST.get('author')
        post_publisher = request.POST.get('publisher')
        post_major = request.POST.get('major')
        books = models.Book.objects.all()

        print(post_major)
        if post_author != "全部":
            books = books.filter(author__a_name=post_author)
        if post_publisher != "全部":
            books = books.filter(publisher__p_name=post_publisher)
        if post_major != "全部":
            books = books.filter(major__m_name=post_major)

        author = models.Author.objects.all()
        publisher = models.Publisher.objects.all()
        major = models.Major.objects.all()
        print(books.count())
        return render(request, 'home.html', locals())


class QueryView(View):
    """
    查询界面
    """

    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')
        user_id = request.session['user_id']
        user_name = User.objects.filter(id=user_id).first().name
        books = models.Book.objects.all()
        author = models.Author.objects.all()
        publisher = models.Publisher.objects.all()
        major = models.Major.objects.all()
        return render(request, "query.html", locals())

    def post(self, request):
        post_author = request.POST.get('author')
        post_publisher = request.POST.get('publisher')
        post_major = request.POST.get('major')
        books = models.Book.objects.all()

        print(post_major)
        if post_author != "全部":
            books = books.filter(author__a_name=post_author)
        if post_publisher != "全部":
            books = books.filter(publisher__p_name=post_publisher)
        if post_major != "全部":
            books = books.filter(major__m_name=post_major)

        author = models.Author.objects.all()
        publisher = models.Publisher.objects.all()
        major = models.Major.objects.all()
        print(books.count())
        return render(request, 'query.html', locals())


class BorrowView(View):
    """
    借书操作
    """

    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')

        user_id = request.session.get('user_id')
        user = User.objects.get(id=user_id)
        book_bno = request.GET.get('book_id')
        books = Book.objects.filter(bno=book_bno, is_available=True)
        if books:
            book = books.first()
            borrow_time = datetime.now()
            return_ddl = borrow_time + timedelta(days=90)
            Borrow.objects.create(user=user, book=book, borrow_time=borrow_time, return_ddl=return_ddl)
            book.is_available = False
            book.save()
            messages.success(request, '借书成功！')
        else:
            messages.error(request, '借书失败：此书不存在或已借出！')
        return redirect('/query/')


class ReturnView(View):
    """
    还书操作
    """

    def get(self, request):
        if not request.session.get('is_login', None):
            messages.error(request, '请先登录！')
            return redirect('/login/')

        user_id = request.session['user_id']
        user = User.objects.get(id=user_id)
        book_bno = request.GET.get('book_id')
        books = Book.objects.filter(bno=book_bno)
        book = books.first()
        borrow_entries = Borrow.objects.filter(user=user, book=book)
        if borrow_entries:
            borrow_entry = borrow_entries.first()
            borrow_entry.delete()
            book.is_available = True
            book.save()
            messages.success(request, '还书成功！')
        else:
            messages.error(request, '还书失败：您未借过此书！')
        return redirect('/home/')
