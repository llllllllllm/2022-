from django.db import models
from datetime import datetime


class User(models.Model):
    """
    用户表
    """
    id = models.CharField(verbose_name='用户名', max_length=8, primary_key=True)
    name = models.CharField(verbose_name='姓名', max_length=30)
    password = models.CharField(verbose_name='密码', max_length=64)
    borrowed_books = models.ManyToManyField('Book', verbose_name='借阅书籍', through='Borrow')

    class Meta:
        verbose_name = '用户'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def __str__(self):
        return str(self.id) + " " + self.name


class Major(models.Model):
    """
    专业表
    """
    m_id = models.CharField(verbose_name='专业号', max_length=20, primary_key=True)
    m_name = models.CharField(verbose_name='专业名称', max_length=40)

    class Meta:
        verbose_name = '专业'
        verbose_name_plural = verbose_name
        ordering = ['m_id']

    def __str__(self):
        return str(self.m_id) + " " + self.m_name


class Publisher(models.Model):
    """
    出版社表
    """
    p_id = models.CharField(verbose_name='出版社号', max_length=20, primary_key=True)
    p_name = models.CharField(verbose_name='出版社名称', max_length=60)

    class Meta:
        verbose_name = '出版社'
        verbose_name_plural = verbose_name
        ordering = ['p_id']

    def __str__(self):
        return str(self.p_id) + " " + self.p_name


class Author(models.Model):
    """
    作者表
    """
    a_id = models.CharField(verbose_name='作者编号', max_length=20, primary_key=True)
    a_name = models.CharField(verbose_name='作者名', max_length=40)

    class Meta:
        verbose_name = '作者'
        verbose_name_plural = verbose_name
        ordering = ['a_id']

    def __str__(self):
        return str(self.a_id) + " " + self.a_name


class Book(models.Model):
    """
    图书表
    """

    bno = models.CharField(verbose_name='图书号', max_length=15, primary_key=True)
    name = models.CharField(verbose_name='书名', max_length=60)
    author = models.ForeignKey(Author, verbose_name='作者', on_delete=models.CASCADE)
    publisher = models.ForeignKey(Publisher, verbose_name="出版社", on_delete=models.CASCADE)
    major = models.ForeignKey(Major, verbose_name="专业", on_delete=models.CASCADE)
    is_available = models.BooleanField(verbose_name='是否可借', default=True)

    class Meta:
        verbose_name = '图书'
        verbose_name_plural = verbose_name
        ordering = ['bno']

    def __str__(self):
        return str(self.bno) + " " + self.name


class Borrow(models.Model):
    """
    借阅关系表
    """
    id = models.AutoField(verbose_name='序号', primary_key=True)
    user = models.ForeignKey(User, verbose_name='借阅者', on_delete=models.CASCADE)
    book = models.ForeignKey(Book, verbose_name='所借书籍', on_delete=models.CASCADE)
    borrow_time = models.DateTimeField(verbose_name='借出时间', default=datetime.now())
    return_ddl = models.DateTimeField(verbose_name='归还期限', default=datetime.now())

    class Meta:
        verbose_name = '借阅关系'
        verbose_name_plural = verbose_name
        ordering = ['user']
        unique_together = (("user", "book"),)

    def __str__(self):
        return '{} borrowed {} at {}'.format(self.user, self.book, self.borrow_time)

